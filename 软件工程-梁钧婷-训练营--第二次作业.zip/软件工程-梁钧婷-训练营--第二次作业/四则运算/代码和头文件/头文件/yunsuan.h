#pragma once
#ifndef YUNSUAN_H_INCLUDED
#define YUNSUAN_H_INCLUDED

typedef enum Status
{
	ERROR = 0, OK = 1
}Status;
//*********************************************
//��������
typedef float ElemType_f;

typedef  struct StackNode_f
{
	ElemType_f data;
	struct StackNode_f *next;
}StackNode_f, *LinkStackPtr_f;

typedef  struct  LinkStack_f {
	LinkStackPtr_f top;	  //ջ��ָ��
	int	count;  //ջ��Ԫ�ظ���
}LinkStack_f;

Status initLStack_f(LinkStack_f *s);
Status isEmptyLStack_f(LinkStack_f *s);
Status getTopLStack_f(LinkStack_f *s, ElemType_f *e);
Status clearLStack_f(LinkStack_f *s);
Status destoryLStack_f(LinkStack_f *s);
Status LStackLength_f(LinkStack_f *s, int *length);
Status pushLStack_f(LinkStack_f *s, ElemType_f datas);
Status popLStack_f(LinkStack_f *s, ElemType_f *datas);

//*********************************************************
//�ַ���
typedef char ElemType_c;
typedef char* er;

typedef  struct StackNode_c
{
	ElemType_c data;
	struct StackNode_c *next;
}StackNode_c, *LinkStackPtr_c;

typedef  struct  LinkStack_c {
	LinkStackPtr_c top;	  //ջ��ָ��
	int	count;  //ջ��Ԫ�ظ���
}LinkStack_c;

Status initLStack_c(LinkStack_c *s);
Status isEmptyLStack_c(LinkStack_c *s);
Status getTopLStack_c(LinkStack_c *s, ElemType_c *e);
Status clearLStack_c(LinkStack_c *s);
Status destoryLStack_c(LinkStack_c *s);
Status LStackLength_c(LinkStack_c *s, int *length);
Status pushLStack_c(LinkStack_c *s, ElemType_c datas);
Status popLStack_c(LinkStack_c *s, ElemType_c *datas);

//**************************************************
//�������
float method_1(LinkStack_f *f, LinkStack_c *c);
float logic(er *arr);
void transform(LinkStack_c *c, LinkStack_f *shu);

#endif // STACK_H_INCLUDED