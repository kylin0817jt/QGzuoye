#include <stdio.h>
#include<stdlib.h>
#include "yunsuan.h"
//************************************************
//����������ջ����
//��ջ(����������)
Status initLStack_f(LinkStack_f *s)   //��ʼ��
{
	if (NULL == s) { return ERROR; }
	s->top = (LinkStackPtr_f)malloc(sizeof(StackNode_f));
	if (NULL == s->top) { return ERROR; }
	s->count = 0;
	s->top->next = NULL;
	return OK;
}

Status isEmptyLStack_f(LinkStack_f *s)  //�ж������Ƿ�Ϊ��
{
	if (NULL == s) { return ERROR; }
	if (s->count == 0) { return OK; }
	else return ERROR;
}

Status getTopLStack_f(LinkStack_f *s, ElemType_f *e)  //�õ�����ͷԪ��
{
	if (NULL == s || NULL == e) { return ERROR; }
	*e = s->top->data;
	return OK;
}

Status clearLStack_f(LinkStack_f *s)   //�������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_f clear = s->top;
	while (s->count != 0) {
		s->top = s->top->next;
		free(clear);
		clear = s->top;
		s->count--;
	}
	return OK;
}

Status destoryLStack_f(LinkStack_f *s)   //��������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_f move = s->top;
	while (s->count != -1) {
		s->top = s->top->next;
		free(move);
		move = s->top;
		s->count--;
	}
	move = NULL;
	s->top = NULL;
	return OK;
}

Status LStackLength_f(LinkStack_f *s, int *length)    //�����������
{
	if (NULL == s || NULL == length) { return ERROR; }
	*length = s->count;
	return OK;
}

Status pushLStack_f(LinkStack_f *s, ElemType_f datas)   //��ջ
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_f add = (LinkStackPtr_f)malloc(sizeof(StackNode_f));
	if (NULL == add) { return ERROR; }
	add->data = datas;
	add->next = s->top;
	s->top = add;
	s->count++;
	return OK;
}

Status popLStack_f(LinkStack_f *s, ElemType_f *datas)   //��ջ
{
	if (NULL == s || NULL == datas || NULL == s->top->next) { return ERROR; }
	LinkStackPtr_f clear = s->top;
	*datas = s->top->data;
	s->top = s->top->next;
	free(clear);
	clear = NULL;
	s->count--;
	return OK;
}
//*************************************************
//�ַ�����ջ����
//��ջ(����������)
Status initLStack_c(LinkStack_c *s)   //��ʼ��
{
	if (NULL == s) { return ERROR; }
	s->top = (LinkStackPtr_c)malloc(sizeof(StackNode_c));
	if (NULL == s->top) { return ERROR; }
	s->count = 0;
	s->top->next = NULL;
	return OK;
}

Status isEmptyLStack_c(LinkStack_c *s)  //�ж������Ƿ�Ϊ��
{
	if (NULL == s) { return ERROR; }
	if (s->count == 0) { return OK; }
	else return ERROR;
}

Status getTopLStack_c(LinkStack_c *s, ElemType_c *e)  //�õ�����ͷԪ��
{
	if (NULL == s || NULL == e) { return ERROR; }
	*e = s->top->data;
	return OK;
}

Status clearLStack_c(LinkStack_c *s)   //�������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_c clear = s->top;
	while (s->count != 0) {
		s->top = s->top->next;
		free(clear);
		clear = s->top;
		s->count--;
	}
	return OK;
}

Status destoryLStack_c(LinkStack_c *s)   //��������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_c move = s->top;
	while (s->count != -1) {
		s->top = s->top->next;
		free(move);
		move = s->top;
		s->count--;
	}
	move = NULL;
	s->top = NULL;
	return OK;
}

Status LStackLength_c(LinkStack_c *s, int *length)    //�����������
{
	if (NULL == s || NULL == length) { return ERROR; }
	*length = s->count;
	return OK;
}

Status pushLStack_c(LinkStack_c *s, ElemType_c datas)   //��ջ
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr_c add = (LinkStackPtr_c)malloc(sizeof(StackNode_c));
	if (NULL == add) { return ERROR; }
	add->data = datas;
	add->next = s->top;
	s->top = add;
	s->count++;
	return OK;
}

Status popLStack_c(LinkStack_c *s, ElemType_c *datas)   //��ջ
{
	if (NULL == s || NULL == datas || NULL == s->top->next) { return ERROR; }
	LinkStackPtr_c clear = s->top;
	*datas = s->top->data;
	s->top = s->top->next;
	free(clear);
	clear = NULL;
	s->count--;
	return OK;
}
//**************************************************************
