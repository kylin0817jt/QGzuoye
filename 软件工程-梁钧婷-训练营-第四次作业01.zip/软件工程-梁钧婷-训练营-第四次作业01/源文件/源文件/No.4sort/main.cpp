#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"Sort.h"
int main() {
	SqList test, *p = &test;
	p->length = 10;
	p->r[0] = 0;
	int i;
	srand(time(NULL));
	for (i = 1; i <= p->length; i++) {
		p->r[i] = (rand() % 100 + 1);
	}
	//insertSort(p);
	
	//mergeSort(p);
	Qsort_Recursion(p);

	//QSort_N(p);
	
	//CountSort(p);
	
	//RadixCountSort(p);
	
	system("pause");
}