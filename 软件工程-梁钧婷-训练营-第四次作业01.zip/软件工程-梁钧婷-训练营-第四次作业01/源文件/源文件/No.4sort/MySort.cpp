#include<stdio.h>
#include<stdlib.h>
#include"Sort.h"
//����������
void Swap(SqList *L, int i, int j) {
	TYPE temp;
	temp = L->r[i];
	L->r[i] = L->r[j];
	L->r[j] = temp;
}
//��������
void insertSort(SqList *L) {
	int i, j;
	for (i = 2; i <= L->length; i++) {
		if (L->r[i] < L->r[i - 1]) {
			L->r[0] = L->r[i];
			for (j = i - 1; L->r[0] < L->r[j]; j--) {
				L->r[j + 1] = L->r[j];
			} 
			L->r[j + 1] = L->r[0];
		}
	}
}
//�鲢����
void mergeSort(p_SqList *p) {
	p_SqList L = *p;
	Msort(L->r, L->r, 1, L->length);
}
void Msort(TYPE SR[], TYPE TR1[], int s, int t) {
	int m;
	int TR2[MAXSIZE + 1];
	if (s == t) {
		TR1[s] = SR[s];		
	}
	else {
		m = (s + t) / 2;
		Msort(SR, TR2, s, m);
		Msort(SR, TR2, m + 1, t);
		Merge(TR2, TR1, s, m, t);
	}
}
void Merge(int SR[], int TR[], int i, int m, int n) {
	int j, k, h;
	for (j = m + 1, k = i; i <= m && j <= n; k++) {
		if (SR[i] < SR[j]) {
			TR[k] = SR[i++];
		}
		else {
			TR[k] = SR[j++];
		}
	}
	if (i <= m) {
		for (h = 0; h < m - i; h++) {
			TR[k + h] = SR[i + h];
		}
	}
	if (j <= n) {
		for (h = 0; h < n - j; h++) {
			TR[k + h] = SR[j + h];
		}
	}
}
//�ݹ���ŷ�
void Qsort_Recursion(SqList *L ) {
	QRSort(L, 1, L->length);
}
void QRSort(SqList *L, int low, int high) {
	TYPE pivot;
	if (low < high) {
		pivot = Partition(L, low, high);
		QRSort(L, low, pivot - 1);
		QRSort(L, pivot + 1, high);
	}
}
TYPE Partition(SqList *L, int low, int high) {
	TYPE pivotkey;
	int m = (low + high) / 2;
	if (L->r[low] > L->r[high]) Swap(L, low, high);
	if (L->r[m] > L->r[high]) Swap(L, m, high);
	if (L->r[m] > L->r[low])  Swap(L, m, low);
	pivotkey = L->r[low];
	L->r[0] = pivotkey;
	while (low < high) {
		while (low < high && L->r[high] >= pivotkey) {
			high--;
		}
		L->r[low] = L->r[high];
		while (low < high && L->r[low] <= pivotkey) {
			low--;
		}
		L->r[high] = L->r[low];
	}
	L->r[low] = L->r[0];
	return low;
}
//�ǵݹ���ŷ�
void QSort_N(SqList *L) {
	Stack record;
	Stack *p = &record;
	p->start[0] = 1;
	p->end[0] = L->length;
	p->top++;
	int i, j;
	int low, high;
	TYPE pivot;
	while (p->top != 0) {
		low = p->start[p->top];
		high = p->end[p->top];
		p->top--;
		pivot = L->r[high];
		i = low;
		for (j = low; j < high; j++) {
			if (L->r[j]<=pivot) {
				Swap(L, i, j);
				i++;
			}
		}
		if (L->r[i] != pivot) {
			Swap(L, high, i);
		}	
		if (i - low > 1) {
			p->start[p->top] = low;
			p->end[p->top] = i - 1;
			p->top++;
		}
		if (high - i > 1) {
			p->start[p->top] = i + 1;
			p->end[p->top] = high;
			p->top++;
		}
	}
}
//��������
void CountSort(SqList *L) {
	int max = L->r[1];
	int i;
	for (i = 2; i <= L->length; i++) {
		if (max < L->r[i]) {
			max = L->r[i];
		}
	}
	int *count = (int*)malloc((max+1) * sizeof(int));
	for (i = 0; i < max + 1; i++) {
		count[i] = 0;
	}
	for (i = 1; i <= L->length; i++) {
		count[L->r[i]]++;
	}
	for (i = 0; i < max ; i++) {
		count[i + 1] += count[i];
	}
	int *countSort = (int*)malloc((L->length) * sizeof(int));
	for (i = 1; i <= L->length; i++) {
		countSort[count[L->r[i] - 1]] = L->r[i];
		count[L->r[i] - 1]--;
	}
}
//����������
void RadixCountSort(SqList *L) {
	int *radixArray[10];
	int i,j = 1;
	int count;
	int num;
	int pos;
	int index;
	int flag = 0;
	for(i=0;i<10;i++){
		radixArray[i] = (int*)malloc((L->length + 1) * sizeof(int));
		radixArray[i][0] = 0;
	}
	for (pos = 0; flag; pos++) {
		for (i = 1,count=1; i <= L->length; i++) {
			num = GetNumInPos(L->r[i], pos);
			if (0 == num) {
				count++;
			}
			if (count == (L->length)) {
				flag = 0;
			}
			index = ++radixArray[num][0];
			radixArray[num][index] = L->r[i];
		}
		for (i = 0; i < 10; i++) {
			for (index = 1; index <= radixArray[i][0]; index++) {
				L->r[j++] = radixArray[i][index];
			}
			radixArray[i][0] = 0;
		}
	}
}
//�õ�pos��Ӧ��λ��
int GetNumInPos(int num, int pos) {
	int i;
	int renum;
	int ten=1;
	for (i = 1; i < pos - 1; i++) {
		ten *= 10;
	}
	renum = (num / ten) % 10;
	return renum;
}
void Print(SqList *L) {
	int i = 0;
	for (i = 0; i <= L->length; i++) {
		printf("%d\t", L->r[i]);
	}
	printf("\n");
}