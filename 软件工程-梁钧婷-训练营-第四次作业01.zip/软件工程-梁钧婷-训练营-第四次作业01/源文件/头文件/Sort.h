#pragma once
#ifndef SORT_H
#define SORT_H
 
typedef	int TYPE;
const int MAXSIZE = 10;
typedef struct Stack {
	int start[MAXSIZE];
	int end[MAXSIZE];
	int top = 0;
}Stack;
typedef struct SqList
{
	int r[MAXSIZE + 1];
	int length;
}SqList,*p_SqList;
void Swap(SqList *L, int i, int j);
void insertSort(SqList *L);
void mergeSort(SqList *L);
void Msort(TYPE SR[], TYPE TR1[], int s, int t);
void Merge(int SR[], int TR[], int i, int m, int n);
void Qsort_Recursion(SqList *L);
void QRSort(SqList *L, int low, int high);
TYPE Partition(SqList *L, int low, int high);
void QSort_N(SqList *L);
void CountSort(SqList *L);
void RadixCountSort(SqList *L);
int GetNumInPos(int num, int pos);
void Print(SqList *L);
#endif // !SORT_H
