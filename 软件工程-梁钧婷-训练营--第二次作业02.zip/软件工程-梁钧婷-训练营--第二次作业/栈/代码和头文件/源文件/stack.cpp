#include <stdio.h>
#include<stdlib.h>
#include "mystack.h"

//˳��ջ(���������)
Status initStack(SqStack *s, int sizes)  //��ʼ������ջ
{
	if (NULL == s || sizes == 0) { return ERROR; }
	s->elem = (ElemType*)malloc(sizes * sizeof(ElemType));
	if (NULL == s->elem) {
		return ERROR;
	}
	s->top = -1;
	s->size = sizes;
	return OK;
}


Status isEmptyStack(SqStack *s)   //�ж�����ջ�Ƿ�Ϊ��
{
	if (NULL == s) { return ERROR; }
	if (s->top == -1) { return OK; }
	else return ERROR;
}


Status getTopStack(SqStack *s, ElemType *e)   //�õ�����ջͷ(top)Ԫ��
{
	if (NULL == s || NULL == e) { return ERROR; }
	if (-1 == s->top) { return ERROR; }
	*e = *(s->elem + s->top);
	return OK;
}


Status clearStack(SqStack *s)   //�������ջ
{
	if (NULL == s) { return ERROR; }
	while (-1 != s->top) {
		*(s->elem + s->top) = 0;
		s->top--;
	}
	return OK;
}


Status destoryStack(SqStack *s)  //��������ջ
{
	if (NULL == s) { return ERROR; }
	free(s->elem);
	s->elem = NULL;
	return OK;
}


Status stackLength(SqStack *s, int *length)   //�������ջ����
{
	if (NULL == s) { return ERROR; }
	*length = s->top + 1;
}

Status pushStack(SqStack *s, ElemType datas)  //��ջ
{
	if (NULL == s || s->top == s->size - 1) { return ERROR; }
	s->top++;
	*(s->elem + s->top) = datas;
	return OK;
}

Status popStack(SqStack *s, ElemType *datas)   //��ջ
{
	if (NULL == s || NULL == datas || -1 == s->top) {return ERROR; }
	else{
		*datas = *(s->elem + s->top);
		s->top--;
		return OK;
	}
}

//��ջ(����������)
Status initLStack(LinkStack *s)   //��ʼ��
{
	if (NULL == s) { return ERROR; }
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	if (NULL == s->top) { return ERROR; }
	s->count = 0;
	s->top->next = NULL;
	return OK;
}

Status isEmptyLStack(LinkStack *s)  //�ж������Ƿ�Ϊ��
{
	if (NULL == s) { return ERROR; }
	if (s->count == 0) { return OK; }
	else return ERROR;
}

Status getTopLStack(LinkStack *s, ElemType *e)  //�õ�����ͷԪ��
{
	if (NULL == s || NULL == e) { return ERROR; }
	*e = s->top->data;
	return OK;
}

Status clearLStack(LinkStack *s)   //�������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr clear = s->top;
	while (s->count != 0) {
		s->top = s->top->next;
		free(clear);
		clear = s->top;
		s->count--;
	}
	return OK;
}

Status destoryLStack(LinkStack *s)   //��������
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr move = s->top;
	while (s->count != -1) {
		s->top = s->top->next;
		free(move);
		move = s->top;
		s->count--;
	}
	move = NULL;
	s->top = NULL;
	return OK;
}

Status LStackLength(LinkStack *s, int *length)    //�����������
{
	if (NULL == s || NULL == length) { return ERROR; }
	*length = s->count;
	return OK;
}

Status pushLStack(LinkStack *s, ElemType datas)   //��ջ
{
	if (NULL == s) { return ERROR; }
	LinkStackPtr add = (LinkStackPtr)malloc(sizeof(StackNode));
	if (NULL == add) { return ERROR; }
	add->data = datas;
	add->next = s->top;
	s->top = add;
	s->count++;
	return OK;
}

Status popLStack(LinkStack *s, ElemType *datas)   //��ջ
{
	if (NULL == s || NULL == datas || NULL == s->top->next) { return ERROR; }
	LinkStackPtr clear = s->top;
	*datas = s->top->data;
	s->top = s->top->next;
	free(clear);
	clear = NULL;
	s->count--;
	return OK;
}
