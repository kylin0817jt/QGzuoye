#include<stdio.h>
#include<stdlib.h>
#include"myqueue.h"
int main() {
	AQueue aq;
	AQueue *p_aq = &aq;
	int i = 0, *pi = &i;
	p_aq->data_size = 4;
	InitAQueue(p_aq);
	if (IsEmptyAQueue(p_aq)) printf("�յ�\n");
	else { printf("����\n"); }
	for (i = 0; i < 10; i++) {
		pi = &i;
		EnAQueue(p_aq, pi);
	}
	TraverseAQueue(p_aq, APrint);
	if (IsFullAQueue) { printf("\n����\n"); }
	else { printf("δ��\n"); }
	printf("������%d\n", LengthAQueue(p_aq));
	printf("\n");
	for (i = 0; i < 2; i++) {
		DeAQueue(p_aq);
	}
	GetHeadAQueue(p_aq, pi);
	printf("ͷԪ����%d\n", *pi);
	TraverseAQueue(p_aq, APrint);
	printf("\n");
	DestoryAQueue(p_aq);
	printf("\n******************\n");
	//*********************
	//�������У�
	LQueue lq, *p_lq = &lq;
	int j, *pj = &j;
	p_lq->data_size = 4;
	InitLQueue(p_lq);
	for (j = 0; j < 10; j++) {
		pj = &j;
		EnLQueue(p_lq, pj);
	}
	TraverseLQueue(p_lq, LPrint);
	printf("\n");
	for (i = 0; i < 3; i++) {
		DeLQueue(p_lq);
	}
	TraverseLQueue(p_lq, LPrint);
	printf("\n");
	GetHeadLQueue(p_lq, pi);
	printf("ͷԪ����%d\n", *pi);
	j=LengthLQueue(p_lq);
	printf("������%d\n",j);
	ClearLQueue(p_lq);
	if (IsEmptyLQueue(p_lq)) { printf("�յ�\n"); }
	else { printf("����\n"); }
	DestoryLQueue(p_lq);
	system("pause");
	return 0;
}