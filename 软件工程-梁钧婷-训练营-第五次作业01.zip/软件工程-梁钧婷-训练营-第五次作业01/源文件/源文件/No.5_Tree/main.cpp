#include<stdio.h>
#include<stdlib.h>
#include"tree.h"
#include"queue.h"
int main() {
	BiTNode bt;
	BiTree pbt = &bt;
	BiTree *ppbt = &pbt;
	Status(*p)(BiTNode);
	p = print;
	InitBiTree(pbt);
	char ch[10] = { 'A','B','#','D','#','#','C','#','#' };
	char *pc = ch;
	CreateBiTree(ppbt, pc);
	PostOrderTraverse(bt, p);
	//InOrderTraverse(bt, p);
	system("pause");
}